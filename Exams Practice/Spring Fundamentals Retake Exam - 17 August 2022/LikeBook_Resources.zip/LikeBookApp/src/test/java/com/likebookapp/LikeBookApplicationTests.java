package com.likebookapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LikeBookApplicationTests {

    @Test
    void contextLoads() {
    }

}
