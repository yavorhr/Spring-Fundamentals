package org.softuni.javache.http;

public interface HttpCookie {
    String getName();

    String getValue();
}
