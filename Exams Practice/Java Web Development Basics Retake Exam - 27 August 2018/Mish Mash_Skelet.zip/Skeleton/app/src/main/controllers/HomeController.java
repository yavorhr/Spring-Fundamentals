package controllers;

import org.softuni.broccolina.solet.HttpSoletRequest;
import org.softuni.summermvc.api.Controller;
import org.softuni.summermvc.api.GetMapping;
import org.softuni.summermvc.api.Model;

@Controller
public class HomeController extends BaseController {
    public HomeController() {
    }

    @GetMapping(route = "/")
    public String index(HttpSoletRequest request) {
        if (super.isLoggedIn(request)) {
            return super.redirect("home");
        }

        return super.view("guest-home");
    }

    @GetMapping(route = "/home")
    public String home(HttpSoletRequest request, Model model) {
        if (!super.isLoggedIn(request)) {
            return super.redirect("login");
        }

        return super.view("user-home");
    }
}
