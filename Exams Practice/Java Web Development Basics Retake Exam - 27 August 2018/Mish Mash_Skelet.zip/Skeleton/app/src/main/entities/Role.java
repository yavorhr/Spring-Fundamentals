package entities;

public enum Role {
    USER,
    ADMIN
}
